#sambungan soalan 3 ....

emailaddress = open('emailaddress.txt', 'r')
print(emailaddress.read())
emailaddress.close()