with open('emailaddress.txt', mode="a") as file:
     file.write("dioncools@gmail.com; ")

with open('emailaddress.txt', mode='a') as file:
    file.write("corbinong@gmail.com; ")

with open('emailaddress.txt', mode='a') as file:
    file.write("sapokbiki@gmail.com; ")

with open('emailaddress.txt', mode='a') as file:
    file.write("watsonnyambek@gmail.com; ")