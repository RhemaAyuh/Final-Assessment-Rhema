#RHEMA ANAK AYUH
#20DDT19F1107


from tkinter import *
from tkinter.font import BOLD


window = Tk()
window.title("GUI EXAMPLE")
window.config(padx=100,pady=50)
window.geometry("300x300")
   
                      
def clickMe():                                               
    action.configure(text="I have been Changed!")

def change(event):       
    action.configure(text="Changed text!")    
                                        
action = Button(window, text="Change Text", command=clickMe)  
action.grid(column=1, row=0)  

action.bind('<Double-1>', change) #SILA KLIK 2 KALI BARU DIA BERTUKAR KE 'CHANGED TEXT'

Label1 = Label(text= "Changed Text")
Label1.grid(column=1, row=1)




window.mainloop()
                    