class Conversion:

    def __init__(self, kg):
        self.kilogram = kg

    def kg_to_pound(self):
        return ('{:.2f} pound').format(self.kilogram * 2.20462)

    def pound_to_kg(self):
        pound2kg_unit = 0.45
        total = self.w * pound2kg_unit
        print("Value : "+str(total)+" KG")

c = Conversion(70)
print(c.kg_to_pound())