print('Enter correct password!')
count=0
while count < 5:
    username = input('Enter username: ')
    password = input('Enter password: ')
    if password=='1234':
        print('You are logged in to the system')
        break
    else:
        print('Access denied. Try again.')
        count += 1